# Converse Client SDK

## Installation

- Create an `extra-modules` folder inside the src directory.
- Place the `converse.svc-client-0.0.2.tgz` file in the extra-modules folder.
- Run the following command:

```sh
  npm i ./src/extra-modules/converse.svc-client-0.0.2.tgz
```

## Initial Setup: Establishing Socket Connection:

### 1. Create Converse instance

```sh
  const converse = new Converse();
```

### 2. Initiate Converse Client SDK

```sh
  const result = await converse.init({
    projectId,
    serverUrl,
    converseToken
  });
```

- projectId - Will be provided by the backend developer.
- serverUrl – Converse server URL. (Optional)
- converseToken – Needs to be generated using your project's backend.
- This method connects to the Converse Socket backend

### 3. Connect to Project Namespace

```sh
  const project = await converse.connectProject();
```

- Connect to your project's Converse backend socket
- Ensure you have [Initiated the Converse Client SDK](#2-initiate-converse-client-sdk) before connecting
- Returns a project instance

### 4. Connect to Channel Namespace

```sh
  const channel = await converse.connectChannel({
    channelId,
  });
```

- Each channel has a unique channelId
- Connect to the channel namespace to emit and listen to channel messages
- Typically done when a user selects a specific chat
- Returns a channel instance

## Other Functions

```sh
  const messages = await channel.getMessages({
    time, reversePaginate, fetchAll
  });
```

- Retrieves all messages from the channel
- time (ISO format)
- reversePaginate and fetchAll are boolean

### Get Message Frame

```sh
  const messages = await channel.getMessageFrame({
    message_id,
    range,
    time,
  });
```

- Fetches the specified message with 20 previous and 20 next messages
- range (number)
- time (ISO format)

### Send Message

```sh
  channel.sendMessage({
    message: "hello",
    meta: {},
    file
  });
```

- message (string) - Text message to send
- meta (object) - Additional metadata (optional)
- file (string) - File URL from backend upload (optional)

### Edit Message

```sh
  channel.editMessage({
    message_id,
    data: { message: "hi", meta: {} },
  });
```

- message_id (string) - ID of the message to edit
- data (object):

  - message (string) - New text message (optional)
  - meta (object) - Additional metadata (optional)

### React to Message

```sh
  channel.reactMessage({ message_id, emote: "👍" });
```

### Update reactions

```sh
  channel.updateReactMessage({
    message_id,
    reactions: [],
  });
```

- Replaces all reactions

### Delete Message for Everyone

```sh
  channel.deleteMessageForEveryone({
    message_id,
  });
```

### Delete Message for Me

```sh
  channel.deleteMessageForMe({
    message_id,
  });
```

### Save last read message

```sh
  channel.saveLastReadMessage()
```

- This will mark all messages as read.

### Start/Stop Typing

```sh
  channel.startTyping()
  channel.stopTyping()
```

### Check for More Messages

```sh
  channel.checkMoreMessage({ time });
```

- time (ISO format)
- Return true or false depending on messages after the specified date
- Need to listen for return value [Listen Check More Messages](#listen-check-more-messages)

### Listen to Edit Message

```sh
  channel.listenEditMessage(({messageId, message, meta}) => {});
```

- Pass a callback function that will be executed when an edited message is detected.
- The callback receives `messageId`, `message`, and `meta` as parameters.

### Listen Message Reaction

```sh
  channel.listenMessageReaction(({message_id, emote, userId})=>{})
```

- The callback receives `message_id`, `emote` and `userId` as parameters.

### Listen Update Message Reaction

```sh
  channel.listenUpdateMessagReaction(({message_id, reactions, userId})=>{})
```

- The callback receives `message_id`, `reactions` and `userId` as parameters.

### Listen Message Delete

```sh
  channel.listenMessageDelete(({messageId})=>{})
```

- The callback receives `messageId` as parameter.

### Listen Last Read Message

```sh
  channel.listenLastReadMessage(()=>{})
```

- This will disconnect the channel namespace

### Listen Start/Stop Typing

```sh
  channel.listenTyping(({uid, name})=>{})
  channel.listenStopTyping(({uid, name})=>{})
```

- This callback receives `uid`-userId and `name` as parameters.

### Listen Check More Messages

```sh
  channel.listenCheckMoreMessage(({haveMoreMessage})=>{})
```

- This callback receives `haveMoreMessage` which returns true or false.

### Listen channel connected

```sh
  channel.listenChannelConnected(()=>{})
```

- This callback not return anything

## Reference

### Disconnect all socket connections

```sh
  converse.shutdown();
```

### Disconnect project namespace connection

```sh
  converse.closeProject();
```

### Disconnect channel namespace connection

```sh
  converse.closeChannel(CHANNEL_ID);
```

- Pass the channelId of the channel you want to disconnect.

### Check the Socket backend connection status

```sh
  const connectionStatus = converse.checkConnection();
```

- This will return a boolean indicating whether the Converse socket backend connection was successful or not.
