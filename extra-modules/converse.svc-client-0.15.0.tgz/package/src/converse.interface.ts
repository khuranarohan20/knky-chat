export interface ConverseInitOptions {
    projectId: string
    converseToken: string,
    serverUrl?: string
}

export interface ConnectChannelParams {
    channelId: string,
    ephemeral?: boolean,
    batch?: number
}