import { Manager } from "socket.io-client";
import { CHAT_SERVER } from "./config";
import { Channel } from "./app";
import { Project } from "./project";

export class Converse {
  channels = new Map();
  projects = new Map();

  constructor() {
    this._manager = null;
    this._socketConnection = null;
  }

  callback(data) {
    return data;
  }

  async init(inputs) {
    const { projectId, converseToken, serverUrl } = inputs;
    console.log("Initiating Connection: ", inputs);
    this.token = converseToken;
    this.projectId = projectId;

    if (serverUrl) {
      CHAT_SERVER.URL = serverUrl;
    }

    const manager = new Manager(`${CHAT_SERVER.URL}`, {
      path: `/api/socket.io`,
      transports: ["websocket"],
      query: {
        token: converseToken,
        projectId: projectId,
      },
    });

    this._manager = manager;

    const socket = manager.socket("/");
    this._socketConnection = socket;

    socket.on("connect", () => {
      console.log("connected", socket.id);
    });

    socket.on("disconnect", () => {
      console.log("disconnected", socket.id);
    });

    socket.on("connect_error", (data) => {
      console.log("from socket", data);
    });

    return "Connection Initiated!";
  }

  checkConnection() {
    if (this._socketConnection && this._socketConnection.connected) {
      return true;
    }
    return false;
  }

  shutdown() {
    // Close all channels
    for (const [id, channel] of this.channels) {
      try {
        channel.close();
      } catch (e) {
        console.error(`Error closing channel ${id}`, e);
      }
    }

    // Close all projects
    for (const [id, project] of this.projects) {
      try {
        project.close();
      } catch (e) {
        console.error(`Error closing project ${id}`, e);
      }
    }

    this._socketConnection.close();
    this.channels.clear();
    this.projects.clear();
  }

  async connectChannel(inputs) {
    if (!this._socketConnection || !this._socketConnection.connected) {
      throw new Error("Converse Manager Is Not Connected!");
    }

    const { channelId, ephemeral = false, batch = 100 } = inputs;

    if (this.channels.get(channelId)) {
      const socket = this.channels.get(channelId).socket;

      if (!socket || !socket.connected) {
        await this.channels.get(channelId).connect(this._manager);
      }

      return this.channels.get(channelId);
    }

    const channel = new Channel(channelId, {
      ephemeral,
      batch,
      projectId: this.projectId,
      token: this.token,
    });

    await channel.init();
    await channel.connect(this._manager);

    this.channels.set(channelId, channel);

    return channel;
  }

  async connectProject() {
    if (!this._socketConnection || !this._socketConnection.connected) {
      throw new Error("Converse Manager Is Not Connected!");
    }

    if (this.projects.get(this.projectId)) {
      const socket = this.projects.get(this.projectId).socket;

      if (!socket || !socket.connected) {
        await this.projects.get(this.projectId).connect(this._manager);
      }

      return this.projects.get(this.projectId);
    }

    const project = new Project(this.projectId, this.token);

    await project.connect(this._manager);
    this.projects.set(this.projectId, project);

    return project;
  }

  async closeChannel(channelId) {
    if (this.channels.get(channelId)) {
      this.channels.get(channelId).close();
    }
  }

  async closeProject() {
    if (this.projects.get(this.projectId)) {
      this.projects.get(this.projectId).close();
    }
  }

  listenConnectionCallback(handler) {
    if (this._socketConnection) {
      this._socketConnection.on("connected", (data) => {
        this.callback(data);
      });
      this.callback = handler;
    } else {
      throw new Error("Socket Not Connected");
    }
  }
}
