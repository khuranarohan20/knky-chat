export const initSocket = async (manager, inputs) => {
  const {
    token,
    channelType,
    channelId,
    projectId,
    open_to_everyone = false,
  } = inputs;

  const auth = {
    type: channelType,
    token,
    projectId,
    open_to_everyone,
  };

  const socket = manager.socket(`/CH-${channelId}`, {
    auth,
  });

  socket.on("connect", () => {
    console.log(socket.id); // x8WIv7-mJelg7on_ALbx
  });

  socket.on("disconnect", () => {
    console.log(socket.id); // undefined
  });
  socket.on("connect_error", (data) => {
    console.log("from socket", data);
  });

  return socket;
};

export const projectSocket = async (manager, inputs) => {
  const { projectId, token } = inputs;

  const auth = {
    token,
  };

  const socket = manager.socket(`/PR-${projectId}`, {
    auth,
  });

  socket.on("connect", () => {
    console.log("Connected: ", socket.id);
  });

  socket.on("disconnect", () => {
    console.log("Disconnected: ", socket.id);
  });

  socket.on("connect_error", (data) => {
    console.log("Socket Error: ", data);
  });

  return socket;
};
