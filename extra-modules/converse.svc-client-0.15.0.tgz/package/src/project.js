import { addPinChannel, getPinnedChannels, unPinChannel } from "./models/channel.model";
import { getMessageUnreadCount, searchMessage } from "./models/message.model";
import { projectSocket } from "./socket";

export class Project {
  constructor(projectId, token) {
    this.projectId = projectId;
    this.token = token;
  }

  async connect(manager) {
    try {
      if (!manager) {
        throw new Error("Converse Manager Required!");
      }
      this.socket = await projectSocket(manager, {
        projectId: this.projectId,
        token: this.token,
      });
      return 0;
    } catch (error) {
      console.log(error);
      throw new Error("Can't connect to Socket!", error);
    }
  }

  async close() {
    try {
      this.socket.disconnect();
      this.socket.removeAllListeners();
    } catch (error) {
      console.log(error);
      throw new Error("Issue is socket!", e);
    }
  }

  newMessageCallback(data) {
    return data;
  }

  messageReadAllCallback(data) {
    return data
  }

  markAsUnreadCallback(data) {
    return data
  }

  seenMessageAllCallback(data) {
    return data;
  }

  editMessageCallback(data) {
    return data;
  }

  seenMessageCallback(data) {
    return data;
  }

  userOnlineCallback(data) {
    return data;
  }

  userOfflineCallback(data) {
    return data;
  }

  deleteMassMessagesStartProcessingCallback(data) {
    return data;
  }

  deleteMassMessagesEndProcessingCallback(data) {
    return data;
  }

  async listenNewMessage(handler) {
    if (this.socket) {
      this.socket.on("new-message", (data) => {
        this.newMessageCallback(data);
      });
      this.newMessageCallback = handler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  async getMessageUnreadCount(inputs) {
    const { isAll = true, isHuman = false, tags = [] } = inputs
    try {
      const data = await getMessageUnreadCount({
        token: this.token,
        projectId: this.projectId,
        isAll,
        isHuman,
        tags
      });

      return {
        msg: "SUCCESS", data
      };
    } catch (e) {
      console.log(e);
      throw new Error("Can't get message unread count !", e);
    }
  }

  async searchMessage(inputs) {
    const { search, channelIds = [] } = inputs
    try {
      const data = await searchMessage({
        token: this.token,
        projectId: this.projectId,
        search,
        channelIds,
      })

      return {
        msg: "SUCCESS", data
      };
    } catch (error) {
      console.log(error);
      throw new Error("Can't search messages !", error);
    }
  }

  async addPinChannel(inputs) {
    const { channel_id } = inputs
    try {
      await addPinChannel({
        token: this.token,
        projectId: this.projectId,
        channel_id,
      })

      return {
        msg: "SUCCESS"
      };
    } catch (error) {
      console.log(error);
      throw new Error("Can't add pin channel !", error);
    }
  }

  async unPinChannel(inputs) {
    const { channel_id } = inputs
    try {
      await unPinChannel({
        token: this.token,
        projectId: this.projectId,
        channel_id,
      })

      return {
        msg: "SUCCESS"
      };
    } catch (error) {
      console.log(error);
      throw new Error("Can't unpin channel !", error);
    }
  }

  async getPinnedChannels(inputs) {
    const { isHuman = true, tags = [] } = inputs;
    try {
      const data = await getPinnedChannels({
        token: this.token,
        projectId: this.projectId,
        isHuman,
        tags,
      })
      return {
        msg: "SUCCESS", data
      };
    } catch (error) {
      console.log(error);
      throw new Error("Can't get pinned channels !", error);
    }
  }

  async messageReadAll(data) {
    if (this.socket) this.socket.emit("message-read-all", data)
    else return { msg: "ERROR", data: "Socket Not Connected" };
  }

  async listenMessageReadAll(handler) {
    if (this.socket) {
      this.socket.on("message-read-all", (data) => {
        this.messageReadAllCallback(data);
      });
      this.messageReadAllCallback = handler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  async markAsUnread(data) {
    if (this.socket) this.socket.emit("mark-as-unread", data)
    else return { msg: "ERROR", data: "Socket Not Connected" };
  }

  async markAsRead(data) {
    if (this.socket) this.socket.emit("mark-as-read", data)
    else return { msg: "ERROR", data: "Socket Not Connected" };
  }

  async listenMarkAsUnread(handler) {
    if (this.socket) {
      this.socket.on("mark-as-unread", (data) => {
        this.markAsUnreadCallback(data);
      });
      this.markAsUnreadCallback = handler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  listenSeenAllMessage(handler) {
    if (this.socket) {
      this.socket.on("message-seen-all", (data) => {
        this.seenMessageAllCallback(data);
      });
      this.seenMessageAllCallback = handler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  async listenEditMessage(handler) {
    if (this.socket) {
      this.socket.on("edit-message", (data) => {
        this.editMessageCallback(data);
      });
      this.editMessageCallback = handler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  listenSeenMessage(handler) {
    if (this.socket) {
      this.socket.on("message-seen", (data) => {
        this.seenMessageCallback(data);
      });
      this.seenMessageCallback = handler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  async joinOnlineUsersRoom() {
    if (this.socket) this.socket.emit("join-online-users-room")
    else return { msg: "ERROR", data: "Socket Not Connected" };
  }

  async exitOnlineUsersRoom() {
    if (this.socket) this.socket.emit("exit-online-users-room")
    else return { msg: "ERROR", data: "Socket Not Connected" };
  }

  listenUserOnline(handler) {
    if (this.socket) {
      this.socket.on("user-online", (data) => {
        this.userOnlineCallback(data);
      });
      this.userOnlineCallback = handler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  listenUserOffline(handler) {
    if (this.socket) {
      this.socket.on("user-offline", (data) => {
        this.userOfflineCallback(data);
      });
      this.userOfflineCallback = handler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  listenDeleteMassMessagesStartProcessing(handler) {
    if (this.socket) {
      this.socket.on("delete-mass-messages-start-processing", (data) => {
        this.deleteMassMessagesStartProcessingCallback(data);
      });
      this.deleteMassMessagesStartProcessingCallback = handler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  listenDeleteMassMessagesEndProcessing(handler) {
    if (this.socket) {
      this.socket.on("delete-mass-messages-end-processing", (data) => {
        this.deleteMassMessagesEndProcessingCallback(data);
      });
      this.deleteMassMessagesEndProcessingCallback = handler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }
}
