import { getChannelById } from "./models/channel.model.js";
import { uploadMedia } from "./models/media.model.js";
import {
  addPinMessage,
  getMessageFrame,
  getMessagesFromChannel,
  getMessagesReceipts,
  getPinnedMessagess,
  unPinMessage,
} from "./models/message.model.js";
import { initSocket } from "./socket.js";

export class Channel {
  constructor(channel_id, options) {
    const { ephemeral = false, batch = 100, projectId = "", token } = options;
    this.channel_id = channel_id;
    this.ephemeral = ephemeral;
    this.batch = batch;
    this.token = token;
    this.projectId = projectId;
  }

  callback(msg) {
    return msg;
  }

  onlineUsersCallback(users) {
    return users;
  }

  messageSeenCallback(data) {
    return data;
  }

  editMessageCallback(data) {
    return data;
  }

  messageReactionCallback(data) {
    return data;
  }

  updateMessageReactionCallback(data) {
    return data;
  }

  deleteMessageCallback(data) {
    return data;
  }

  deleteMessageMeCallback(data) {
    return data;
  }

  saveLastReadMessageCallback(data) {
    return data;
  }

  typingCallback(data) {
    return data;
  }

  stopTypingCallback(data) {
    return data;
  }

  checkMoreMessageCallback(data) {
    return data;
  }

  channelConnectedCallback(data) {
    return data;
  }

  seenMessageCallback(data) {
    return data;
  }

  seenMessageAllCallback(data) {
    return data;
  }

  pinMessageCallback(data) {
    return data;
  }

  unPinMessageCallback(data) {
    return data;
  }

  editPinMessageCallback(data) {
    return data;
  }

  /**
   *
   * @param {*} token project's jwt
   * @param {*} projectId unique id of project
   * @returns converse jwt
   */
  async init() {
    if (!this.ephemeral) {
      await this.setChannel(this.channel_id);
    } else {
      await this.getEphemeralChannel();
    }
  }

  /**
   *
   * @param {*} channel_id channel id
   * @returns channel instance => type, channel_id, etc..
   */
  async setChannel(channel_id) {
    try {
      this.channel = await getChannelById({
        channel_id,
        projectId: this.projectId,
        token: this.token,
      });

      if (!this.channel) {
        throw new Error("Channel Not Found!");
      }

      return this.channel;
    } catch (e) {
      console.log(e);
      throw new Error("Channel Id not correct !", e);
    }
  }

  async connect(manager) {
    try {
      if (!manager) {
        throw new Error("Converse Manager Required!");
      }
      this.socket = await initSocket(manager, {
        token: this.token,
        channelType: this.channel.type,
        channelId: this.channel_id,
        projectId: this.projectId,
        open_to_everyone: this.channel.open_to_everyone || false,
      });
      return 0;
    } catch (e) {
      console.log(e);
      throw new Error("Can't connect to Socket !", e);
    }
  }

  async close() {
    try {
      this.socket.disconnect();
      this.socket.removeAllListeners();
    } catch (e) {
      console.log(e);
      throw new Error("Issue is socket !", e);
    }
  }

  /**
   *
   * @param {*} channel
   * @returns {...Array} msgs
   */
  async getMessages(inputs = {}) {
    const {
      time = new Date().toISOString(),
      reversePaginate = false,
      fetchAll = false,
      isUnreadMessage = false,
    } = inputs;
    try {
      const msgs = await getMessagesFromChannel({
        channel: this.channel,
        user_id: this.user_id,
        time: new Date(time).toISOString(),
        batch: this.batch,
        token: this.token,
        projectId: this.projectId,
        reversePaginate,
        fetchAll,
        isUnreadMessage,
      });

      if (!reversePaginate) {
        msgs.read && msgs.read.length && msgs.read.reverse();
        msgs.unread && msgs.unread.length && msgs.unread.reverse();
      }

      return { msg: "SUCCESS", msgs: msgs };
    } catch (e) {
      console.log(e);
      throw new Error("Can't get messages !", e);
    }
  }

  async getMessageFrame(inputs) {
    const { message_id, range } = inputs;
    try {
      const msgs = await getMessageFrame({
        message_id,
        range,
        project_id: this.projectId,
        channel: this.channel,
        token: this.token,
      });
      return { msg: "SUCCESS", msgs: msgs };
    } catch (error) {
      console.log(error);
      throw new Error("Can't get mesaages frame !", error);
    }
  }

  async getMessagesReceipts(inputs = {}) {
    const {
      time = new Date().toISOString(),
      reversePaginate = false,
      fetchAll = false,
    } = inputs;
    try {
      const receipts = await getMessagesReceipts({
        channel: this.channel,
        user_id: this.user_id,
        time: new Date(time).toISOString(),
        batch: this.batch,
        token: this.token,
        projectId: this.projectId,
        reversePaginate,
        fetchAll,
      });

      return { msg: "SUCCESS", receipts: receipts };
    } catch (e) {
      console.log(e);
      throw new Error("Can't get messages receipts!", e);
    }
  }

  async addPinMessage(inputs) {
    const { messageId, forAll = false } = inputs;
    try {
      await addPinMessage({
        channel: this.channel,
        token: this.token,
        projectId: this.projectId,
        messageId,
        forAll,
      });

      return { msg: "SUCCESS" };
    } catch (e) {
      console.log(e);
      throw new Error("Can't add pin message!", e);
    }
  }

  async unPinMessage(inputs) {
    const { messageId, forAll = false, pinId } = inputs;
    try {
      await unPinMessage({
        channel: this.channel,
        token: this.token,
        projectId: this.projectId,
        messageId,
        forAll,
        pinId,
      });

      return { msg: "SUCCESS" };
    } catch (e) {
      console.log(e);
      throw new Error("Can't unpin message!", e);
    }
  }

  async getPinnedMessages(inputs) {
    const { page = 1, limit = 10, reversePaginate = false } = inputs;
    try {
      const data = await getPinnedMessagess({
        channel: this.channel,
        token: this.token,
        projectId: this.projectId,
        page,
        limit,
        reversePaginate,
      });

      return { msg: "SUCCESS", data };
    } catch (e) {
      console.log(e);
      throw new Error("Can't add pin message!", e);
    }
  }

  /**
   *
   * @param {*} msgHandler Function to handle received messages
   */
  async listenMessage(msgHandler) {
    if (this.socket) {
      this.socket.on("message", (msg) => {
        this.callback(msg);
      });
      this.callback = msgHandler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  /**
   *
   * @param {*} msg msg object/ var to be sent
   */
  async sendMessage(msg) {
    if (msg.file) {
      const data = await uploadMedia(msg, {
        token: this.token,
        projectId: this.projectId,
      });
      msg.file = data.url;
    }
    if (this.socket) this.socket.emit("message", msg);
    else return { msg: "ERROR", data: "Socket Not Connected" };
  }

  /**
   *
   * @param {*} creationTime message Creation Time
   * @param {*} message_id unique_id of message
   * @param {*} data data to edit
   * @returns
   */
  async editMessage(inputs) {
    const { message_id, data = {} } = inputs;
    if (this.socket && Object.keys(data).length) {
      this.socket.emit("edit-message", { message_id, data });
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  /**
   *
   * @param {*} creationTime message Creation Time
   * @param {*} message_id unique_id of message
   * @param {*} emote reaction
   * @returns
   */
  async reactMessage(inputs) {
    const { message_id, emote } = inputs;
    if (this.socket) {
      this.socket.emit("react-message", { message_id, emote });
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  /**
   *
   * @param {*} creationTime message Creation Time
   * @param {*} message_id unique_id of message
   * @param {*} reactions updated Reaction Array
   * @returns
   */
  async updateReactMessage(inputs) {
    const { message_id, reactions } = inputs;
    if (this.socket) {
      this.socket.emit("update-reaction", {
        message_id,
        reactions,
      });
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  /**
   *
   * @param {*} creationTime message Creation Time
   * @param {*} message_id unique_id of message
   * @returns
   */
  async deleteMessageForEveryone(inputs) {
    const { message_id } = inputs;
    if (this.socket) {
      this.socket.emit("delete-message-everyone", { message_id });
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  async deleteMessageForMe(inputs) {
    const { message_id } = inputs;
    if (this.socket) {
      this.socket.emit("delete-message-me", { message_id });
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  async saveLastReadMessage() {
    if (this.socket) {
      this.socket.emit("save-lastread-message");
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  startTyping(meta) {
    if (this.socket) {
      this.socket.emit("typing", { meta });
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  stopTyping(meta) {
    if (this.socket) {
      this.socket.emit("stop-typing", { meta });
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  checkMoreMessage(inputs) {
    if (this.socket) {
      this.socket.emit("check-more-message", { time: inputs?.time });
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  /**
   *
   * @param {*} handler Function to handle online users list
   */
  async listenOnlineUsers(handler) {
    try {
      if (this.socket) {
        this.socket.on("users", (data) => {
          this.onlineUsersCallback(data);
        });
        this.onlineUsersCallback = handler;
      }
    } catch (error) {
      console.log(error);
      throw new Error("No Data Found!");
    }
  }

  /**
   *
   * @param {*} handler Function to handle edit message event
   */
  async listenEditMessage(handler) {
    if (this.socket) {
      this.socket.on("edit-message", (data) => {
        this.editMessageCallback(data);
      });
      this.editMessageCallback = handler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  /**
   *
   * @param {*} handler Function to handle message reaction event
   */
  async listenMessageReaction(handler) {
    if (this.socket) {
      this.socket.on("react-message", (data) => {
        this.messageReactionCallback(data);
      });
      this.messageReactionCallback = handler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  /**
   *
   * @param {*} handler Function to handle message edit event
   */
  async listenUpdateMessagReaction(handler) {
    if (this.socket) {
      this.socket.on("update-reaction", (data) => {
        this.updateMessageReactionCallback(data);
      });
      this.updateMessageReactionCallback = handler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  /**
   *
   * @param {*} handler Function to handle message edit event
   */
  async listenMessageDelete(handler) {
    if (this.socket) {
      this.socket.on("delete-message-everyone", (data) => {
        this.deleteMessageCallback(data);
      });
      this.deleteMessageCallback = handler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  async listenMessageDeleteMe(handler) {
    if (this.socket) {
      this.socket.on("delete-message-me", (data) => {
        this.deleteMessageMeCallback(data);
      });
      this.deleteMessageMeCallback = handler;
    } else {
      return { msg: "ERROR", data: "Socket Not Connected" };
    }
  }

  async listenLastReadMessage(handler) {
    if (this.socket) {
      this.socket.on("disconnect-socket", () => {
        this.close();
        this.saveLastReadMessageCallback();
      });
      this.saveLastReadMessageCallback = handler;
    }
  }

  async seenMessage(messages) {
    if (this.socket) this.socket.emit("message-seen", { messages });
    else return { msg: "ERROR", data: "Socket Not Connected" };
  }

  async seenMessageAll(data) {
    if (this.socket) this.socket.emit("message-seen-all", data);
    else return { msg: "ERROR", data: "Socket Not Connected" };
  }

  async massDeleteMessage(data) {
    if (data.messageIds.length > 100) return { msg: "ERROR", data: "Max 100 message ids allowed" };
    if (this.socket) this.socket.emit("mass-delete-message", data);
    else return { msg: "ERROR", data: "Socket Not Connected" };
  }

  listenTyping(handler) {
    if (this.socket) {
      this.socket.on("typing", (data) => {
        this.typingCallback(data);
      });
      this.typingCallback = handler;
    }
  }

  listenStopTyping(handler) {
    if (this.socket) {
      this.socket.on("stop-typing", (data) => {
        this.stopTypingCallback(data);
      });
      this.stopTypingCallback = handler;
    }
  }

  listenCheckMoreMessage(handler) {
    if (this.socket) {
      this.socket.on("check-more-message", (data) => {
        this.checkMoreMessageCallback(data);
      });
      this.checkMoreMessageCallback = handler;
    }
  }

  listenChannelConnected(handler) {
    if (this.socket) {
      this.socket.on("channel-connected", (data) => {
        this.channelConnectedCallback(data);
      });
      this.channelConnectedCallback = handler;
    }
  }

  listenSeenMessage(handler) {
    if (this.socket) {
      this.socket.on("message-seen", (data) => {
        this.seenMessageCallback(data);
      });
      this.seenMessageCallback = handler;
    }
  }

  listenSeenAllMessage(handler) {
    if (this.socket) {
      this.socket.on("message-seen-all", (data) => {
        this.seenMessageAllCallback(data);
      });
      this.seenMessageAllCallback = handler;
    }
  }

  listenPinMessage(handler) {
    if (this.socket) {
      this.socket.on("pin-message", (data) => {
        this.pinMessageCallback(data);
      });
      this.pinMessageCallback = handler;
    }
  }

  listenUnPinMessage(handler) {
    if (this.socket) {
      this.socket.on("unpin-message", (data) => {
        this.unPinMessageCallback(data);
      });
      this.unPinMessageCallback = handler;
    }
  }

  listenEditPinMessage(handler) {
    if (this.socket) {
      this.socket.on("edit-pin-message", (data) => {
        this.editPinMessageCallback(data);
      });
      this.editPinMessageCallback = handler;
    }
  }
}
