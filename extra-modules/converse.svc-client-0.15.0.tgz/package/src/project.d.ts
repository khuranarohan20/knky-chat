import { AddPinChannelParams, AddPinChannelResponse, GetMessageUnreadCountParams, GetMessageUnreadCountResponse, GetPinnedChannelsParams, GetPinnedChannelsResponse, MarkAsReadParams, MarkAsUnreadParams, MessageReadAllParams, SearchMessageParams, SearchMessageResponse, UnPinChannelParams, UnPinChannelResponse } from "./project.interface";

export declare class Project {
    constructor(projectId: string, token: string)

    connect(): Promise<number>

    listenNewMessage(handlerFunction: Function): void

    close(): void

    getMessageUnreadCount(inputs: GetMessageUnreadCountParams): Promise<GetMessageUnreadCountResponse>

    searchMessage(inputs: SearchMessageParams): Promise<SearchMessageResponse>

    addPinChannel(inputs: AddPinChannelParams): Promise<AddPinChannelResponse>

    unPinChannel(inputs: UnPinChannelParams): Promise<UnPinChannelResponse>

    getPinnedChannels(inputs: GetPinnedChannelsParams): Promise<GetPinnedChannelsResponse>

    messageReadAll(inputs: MessageReadAllParams): void

    listenMessageReadAll(handlerFunction: Function): void

    markAsUnread(inputs: MarkAsUnreadParams): void

    markAsRead(inputs: MarkAsReadParams): void

    joinOnlineUsersRoom(): void

    exitOnlineUsersRoom(): void

    listenMarkAsUnread(handlerFunction: Function): void

    listenSeenAllMessage(handlerFunction: Function): void

    listenEditMessage(handlerFunction: Function): void

    listenSeenMessage(handlerFunction: Function): void

    listenUserOnline(handlerFunction: Function): void

    listenUserOffline(handlerFunction: Function): void

    listenDeleteMassMessagesStartProcessing(handlerFunction: Function): void

    listenDeleteMassMessagesEndProcessing(handlerFunction: Function): void
}
