export interface ChannelOptions {
    ephemeral?: boolean,
    batch?: number,
    projectId: string,
    token: string
}

export interface ChannelInitParams {
    token: string
    project_id: string
}

export interface GetMessageParams {
    time?: string,
    reversePaginate?: boolean,
    fetchAll?: boolean,
    isUnreadMessage?: boolean,
}

export interface GetMessagesReceiptsParams {
    time?: string,
    reversePaginate?: boolean,
    fetchAll?: boolean
}

export interface ChannelConnectParams {
    token: string
}

export interface GetMessagesResponse {
    msg: string,
    msgs: {
        read: Record<string, any>[]
        unread: Record<string, any>[]
    }
}

export interface GetMessagesReceiptsResponse {
    msg: string,
    receipts: {
        _id: string,
        receipts: {
            user_id: string,
            time: string,
            status: "seen"
        }[]
    }[]
}

export interface GetMessageFrameParams {
    message_id: string
    range: number
}

export interface SendMessageParams {
    file?: File | any
    message?: string
    name?: string
    meta?: Record<string, any>
    reqSearch?: string[],
}

export interface EditMessageParams {
    message_id: string
    data: {
        message?: string
        meta?: Record<string, any>
    }
}

export interface ReactMessageParams {
    message_id: string
    emote: any
}

export interface UpdateReactMessageParams {
    message_id: string
    reactions: any[]
}

export interface DeleteMessageParams {
    message_id: string
}

export interface CheckMoreMessageParams {
    time: string
}

export interface SeenMessageParams {
    senderId: string
    messageId: string
}

export interface SeenMessageAllParams {
    time?: string
}

export interface AddPinMessageParams {
    messageId: string,
    forAll?: boolean,
}

export interface AddPinMessageResponse {
    msg: string
}

export interface UnPinMessageParams {
    messageId: string,
    forAll?: boolean,
    pinId?: string,
}

export interface UnPinMessageResponse {
    msg: string
}

export interface GetPinnedMessagesParams {
    page?: number,
    limit?: number,
    reversePaginate?: boolean,
}

export interface GetPinnedMessagesResponse {
    msg: string
    data: {
        pinnedMsgs: Record<string, any>[]
    }
}

export interface MassDeleteMessageParams {
    messageIds: string[],
    delete_for_everyone: boolean,
}