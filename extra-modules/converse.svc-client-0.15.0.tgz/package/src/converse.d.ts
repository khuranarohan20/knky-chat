import { Channel } from "./app";
import { ConnectChannelParams, ConverseInitOptions } from "./converse.interface";
import { Project } from "./project";

export declare class Converse {
    constructor()

    init(inputs: ConverseInitOptions): Promise<string>

    checkConnection(): boolean

    connectChannel(inputs: ConnectChannelParams): Promise<Channel>

    connectProject(): Promise<Project>

    closeChannel(channelId: string): void

    closeProject(): void

    shutdown(): void

    listenConnectionCallback(handler: Function): void

}