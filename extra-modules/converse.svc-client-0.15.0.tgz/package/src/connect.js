import { CHAT_SERVER } from "./config.js";

export const postApiResponse = async (endpoint, body, headers) => {
  const url = `${CHAT_SERVER.URL}/client/`;
  const data = await fetch(`${url}${endpoint}`, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      "x-nonce": headers.token,
      projectId: headers.projectId,
    },
    mode: "cors", // no-cors, *cors, same-origin
    body: JSON.stringify(body),
  })
    .then((res) => res.json())
    .then((data) => {
      return data.data;
    })
    .catch((err) => console.log(err));

  return data;
};

export const getApiResponse = async (endpoint, headers) => {
  const url = `${CHAT_SERVER.URL}/client/`;
  const urlParams = new URL(`${url}${endpoint}`);
  const data = await fetch(urlParams, {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      "x-nonce": headers.token,
      projectId: headers.projectId,
    },
  })
    .then((res) => res.json())
    .then((data) => {
      return data.data;
    })
    .catch((err) => console.log(err));

  return data;
};

export const postApiRequestFormData = async (endpoint, body, headers) => {
  const url = `${CHAT_SERVER.URL}/client/`;
  const data = await fetch(`${url}${endpoint}`, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "x-nonce": headers.token,
      projectId: headers.projectId,
    },
    mode: "cors", // no-cors, *cors, same-origin
    body,
  })
    .then((res) => res.json())
    .then((data) => {
      return data.data;
    })
    .catch((err) => console.log(err));

  return data;
};
// module.exports= {getApiResponse, postApiResponse};
