export interface GetMessageUnreadCountParams {
    isAll?: boolean,
    isHuman?: boolean,
    tags?: Array<string>
}

export interface GetMessageUnreadCountResponse {
    msg: string,
    data: {
        totalUnreadCount: number,
        channelCount: number,
        channels: { channelId: string, unreadCount: number }[],
    }
}

export interface SearchMessageParams {
    search: string,
    channelIds?: string[],
}

export interface SearchMessageResponse {
    msg: string,
    data: {
        messages: Record<string, any>[]
    }
}

export interface AddPinChannelParams {
    channel_id: string
}

export interface AddPinChannelResponse {
    msg: string
}

export interface UnPinChannelParams {
    channel_id: string
}

export interface UnPinChannelResponse {
    msg: string
}

export interface GetPinnedChannelsParams {
    isHuman?: boolean,
    tags?: Array<string>
}

export interface GetPinnedChannelsResponse {
    msg: string,
    data: {
        pinnedChannels: Record<string, any>[]
    }
}

export interface MessageReadAllParams {
    time?: string,
}

export interface MarkAsUnreadParams {
    channelIds: string[],
}

export interface MarkAsReadParams {
    channelId: string
}