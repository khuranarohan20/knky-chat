import {
    ChannelOptions,
    GetMessageFrameParams,
    GetMessagesResponse,
    SendMessageParams,
    EditMessageParams,
    ReactMessageParams,
    UpdateReactMessageParams,
    DeleteMessageParams,
    GetMessageParams,
    CheckMoreMessageParams,
    GetMessagesReceiptsParams,
    GetMessagesReceiptsResponse,
    SeenMessageParams,
    SeenMessageAllParams,
    AddPinMessageResponse,
    AddPinMessageParams,
    UnPinMessageParams,
    UnPinMessageResponse,
    GetPinnedMessagesParams,
    GetPinnedMessagesResponse,
    MassDeleteMessageParams,
} from './channel.interface'

export declare class Channel {

    constructor(channel_id: string, options: ChannelOptions);

    getMessages(inputs: GetMessageParams): Promise<GetMessagesResponse>

    getMessageFrame(inputs: GetMessageFrameParams): Promise<GetMessagesResponse>

    getMessagesReceipts(inputs: GetMessagesReceiptsParams): Promise<GetMessagesReceiptsResponse>

    addPinMessage(inputs: AddPinMessageParams): Promise<AddPinMessageResponse>

    unPinMessage(inputs: UnPinMessageParams): Promise<UnPinMessageResponse>

    getPinnedMessages(inputs: GetPinnedMessagesParams): Promise<GetPinnedMessagesResponse>

    sendMessage(inputs: SendMessageParams): Promise<void>

    editMessage(inputs: EditMessageParams): void

    reactMessage(inputs: ReactMessageParams): void

    updateReactMessage(inputs: UpdateReactMessageParams): void

    deleteMessageForEveryone(inputs: DeleteMessageParams): void

    deleteMessageForMe(inputs: DeleteMessageParams): void

    saveLastReadMessage(): void

    startTyping(meta?: Record<string, any>): void

    stopTyping(meta?: Record<string, any>): void

    checkMoreMessage(inputs: CheckMoreMessageParams): Promise<void>

    seenMessage(messages: SeenMessageParams[]): void

    seenMessageAll(inputs: SeenMessageAllParams): Promise<void>

    massDeleteMessage(inputs: MassDeleteMessageParams): Promise<void>

    listenMessage(handlerFunction: Function): void

    listenOnlineUsers(handlerFunction: Function): void

    listenEditMessage(handlerFunction: Function): void

    listenMessageReaction(handlerFunction: Function): void

    listenUpdateMessagReaction(handlerFunction: Function): void

    listenMessageDelete(handlerFunction: Function): void

    listenMessageDeleteMe(handlerFunction: Function): void

    listenLastReadMessage(handlerFunction: Function): void

    listenTyping(handlerFunction: Function): void

    listenStopTyping(handlerFunction: Function): void

    listenCheckMoreMessage(handlerFunction: Function): void

    listenChannelConnected(handlerFunction: Function): void

    listenSeenMessage(handlerFunction: Function): void

    listenSeenAllMessage(handlerFunction: Function): void

    listenPinMessage(handlerFunction: Function): void

    listenUnPinMessage(handlerFunction: Function): void

    listenEditPinMessage(handlerFunction: Function): void
}
