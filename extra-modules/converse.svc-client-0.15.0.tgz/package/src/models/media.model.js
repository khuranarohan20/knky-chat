import { postApiRequestFormData } from "../connect.js";

export const uploadMedia = async (msg, options) => {
  const { file } = msg;
  const { token, projectId } = options;
  const formData = new FormData();
  formData.append("file", file);
  return await postApiRequestFormData("media", formData, {
    token,
    projectId,
  });
};
