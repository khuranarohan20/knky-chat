// const { postApiResponse } = require("../../connect");
import { getApiResponse, postApiResponse } from "../connect.js";

export const getMessagesFromChannel = async (inputs) => {
  const {
    channel,
    user_id,
    time,
    batch,
    reversePaginate = false,
    token,
    projectId,
    fetchAll = false,
    isUnreadMessage = false,
  } = inputs;
  const { type, channel_id } = channel;
  let limit = batch;
  const endpoint = "message/get-messages";
  const body = {
    channel_id,
    user_id,
    limit,
    time,
    reversePaginate,
    type,
    fetchAll,
    isUnreadMessage,
  };
  const headers = {
    token,
    projectId,
  };
  return await postApiResponse(endpoint, body, headers);
};

export const getMessageFrame = async (inputs) => {
  const { message_id, range, project_id, channel, token } =
    inputs;
  const { channel_id } = channel;
  const endpoint = "message/get-message-frame";
  const body = {
    message_id,
    range,
    project_id,
    channel_id,
  };
  const headers = {
    token,
    projectId: project_id,
  };
  return await postApiResponse(endpoint, body, headers);
};

export const getMessageUnreadCount = async (inputs) => {
  const {
    token,
    projectId,
    isAll = true,
    isHuman = false,
    tags = []
  } = inputs;
  const endpoint = "message/get-message-unread-count";
  const body = {
    isAll,
    isHuman,
    tags
  }
  const headers = {
    token,
    projectId,
  };
  return await postApiResponse(endpoint, body, headers);
};

export const getMessagesReceipts = async (inputs) => {
  const {
    channel,
    user_id,
    time,
    batch,
    reversePaginate = false,
    token,
    projectId,
    fetchAll = false,
  } = inputs;
  const { type, channel_id } = channel;
  let limit = batch;
  const endpoint = "message/get-messages-receipts";
  const body = {
    channel_id,
    user_id,
    limit,
    time,
    reversePaginate,
    type,
    fetchAll,
  };
  const headers = {
    token,
    projectId,
  };
  return await postApiResponse(endpoint, body, headers);
};


export const searchMessage = async (inputs) => {
  const {
    token,
    projectId,
    search,
    channelIds = [],
  } = inputs;
  const endpoint = "message/search-messages";
  const body = {
    search,
    channelIds
  }
  const headers = {
    token,
    projectId,
  };
  return await postApiResponse(endpoint, body, headers);
};

export const addPinMessage = async (inputs) => {
  const {
    channel,
    token,
    projectId,
    messageId,
    forAll = false
  } = inputs
  const { channel_id } = channel;
  const endpoint = "message/pin-message";
  const body = {
    channelId: channel_id,
    messageId,
    forAll,
  };
  const headers = {
    token,
    projectId,
  };
  return await postApiResponse(endpoint, body, headers);
}

export const unPinMessage = async (inputs) => {
  const {
    channel,
    token,
    projectId,
    messageId,
    forAll = false,
    pinId,
  } = inputs
  const { channel_id } = channel;
  const endpoint = "message/unpin-message";
  const body = {
    channelId: channel_id,
    messageId,
    forAll,
    pinId,
  };
  const headers = {
    token,
    projectId,
  };
  return await postApiResponse(endpoint, body, headers);
}

export const getPinnedMessagess = async (inputs) => {
  const {
    channel,
    token,
    projectId,
    page = 1,
    limit = 10,
    reversePaginate = false
  } = inputs
  const { channel_id } = channel;
  const endpoint = "message/get-pinned-messages";
  const body = {
    channelId: channel_id,
    page,
    limit,
    reversePaginate,
  };
  const headers = {
    token,
    projectId,
  };
  return await postApiResponse(endpoint, body, headers);
}