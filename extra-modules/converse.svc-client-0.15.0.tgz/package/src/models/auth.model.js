import { postApiResponse } from "../connect.js";

export const verifyToken = async (token, projectId) => {
  const body = { token, projectId };
  return await postApiResponse("auth/verify-token", body);
};
