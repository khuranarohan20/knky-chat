import { getApiResponse, postApiResponse } from "../connect.js";

export const getChannelById = async (inputs) => {
  const { channel_id, projectId, token } = inputs;
  const headers = {
    token,
    projectId,
  };

  const endPoint = `channel/${channel_id}`;
  return await getApiResponse(endPoint, headers);
};


export const addPinChannel = async (inputs) => {
  const { channel_id, projectId, token } = inputs;
  const headers = {
    token,
    projectId,
  };
  const body = {
    channelId: channel_id,
  }
  const endPoint = "channel/pin-channel";
  return await postApiResponse(endPoint, body, headers)
}

export const unPinChannel = async (inputs) => {
  const { channel_id, projectId, token } = inputs;
  const headers = {
    token,
    projectId,
  };
  const body = {
    channelId: channel_id,
  }
  const endPoint = "channel/unpin-channel";
  return await postApiResponse(endPoint, body, headers)
}

export const getPinnedChannels = async (inputs) => {
  const { isHuman = true, projectId, token, tags } = inputs;
  const headers = {
    token,
    projectId,
  };
  const body = {
    isHuman,
    tags,
  }
  const endPoint = "channel/get-pinned-channels";
  return await postApiResponse(endPoint, body, headers)
}