export const CHAT_SERVER = {
    URL: "https://backend.converse.svc.inkincaps.com"
};
